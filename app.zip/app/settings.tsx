﻿import { useState } from 'react'
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, Switch, Alert, Clipboard, Modal, Animated,
} from 'react-native'
import { router } from 'expo-router'
import { useWalletStore } from '../store/walletStore'
import { CHAINS } from '../utils/chains'

type Section = { title: string; items: Item[] }
type Item = {
  icon: string; label: string; sublabel?: string
  type: 'nav' | 'toggle' | 'action' | 'info'
  value?: boolean; color?: string
  onPress?: () => void
  onToggle?: (v: boolean) => void
}

export default function Settings() {
  const addr        = useWalletStore(s => s.address)
  const activeChain = useWalletStore(s => s.activeChain)
  const clearWallet = useWalletStore(s => s.clearWallet)

  const [biometrics,     setBiometrics]     = useState(false)
  const [notifications,  setNotifications]  = useState(true)
  const [hideBalance,    setHideBalance]    = useState(false)
  const [testnet,        setTestnet]        = useState(false)
  const [copied,         setCopied]         = useState(false)

  const short = addr ? addr.slice(0, 10) + '...' + addr.slice(-8) : ''

  const copyAddress = () => {
    if (addr) {
      Clipboard.setString(addr)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const confirmWipe = () => {
    Alert.alert(
      ' Wipe Wallet',
      'This will permanently delete your wallet from this device. Make sure you have backed up your seed phrase.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Wipe Wallet',
          style: 'destructive',
          onPress: () => {
            clearWallet?.()
            router.replace('/')
          },
        },
      ]
    )
  }

  const sections: Section[] = [
    {
      title: 'Wallet',
      items: [
        {
          icon: '📋', label: 'Wallet Address',
          sublabel: short, type: 'action',
          onPress: copyAddress,
        },
        {
          icon: '🔑', label: 'Export Private Key',
          sublabel: 'Tap to reveal (keep secret)',
          type: 'nav',
          onPress: () => Alert.alert('Security Notice', 'Never share your private key. This feature requires biometric authentication.'),
        },
        {
          icon: '📝', label: 'Backup Seed Phrase',
          sublabel: 'Verify your recovery words',
          type: 'nav',
          onPress: () => Alert.alert('Backup', 'Write down your 12-word seed phrase and store it safely offline.'),
        },
        {
          icon: '🌐', label: 'Active Network',
          sublabel: activeChain.name,
          type: 'info',
        },
      ],
    },
    {
      title: 'Security',
      items: [
        {
          icon: '👁', label: 'Hide Balance',
          sublabel: 'Mask amounts on dashboard',
          type: 'toggle',
          value: hideBalance,
          onToggle: setHideBalance,
        },
        {
          icon: '🔒', label: 'Biometric Lock',
          sublabel: 'Require Face ID / fingerprint',
          type: 'toggle',
          value: biometrics,
          onToggle: setBiometrics,
        },
      ],
    },
    {
      title: 'App',
      items: [
        {
          icon: '🔔', label: 'Push Notifications',
          sublabel: 'Transaction alerts',
          type: 'toggle',
          value: notifications,
          onToggle: setNotifications,
        },
        {
          icon: '🧪', label: 'Testnet Mode',
          sublabel: 'Show test networks',
          type: 'toggle',
          value: testnet,
          onToggle: setTestnet,
        },
        {
          icon: '📜', label: 'Transaction History',
          sublabel: 'View all past activity',
          type: 'nav',
          onPress: () => router.push('/history' as any),
        },
        {
          icon: '', label: 'Address Book',
          sublabel: 'Saved contacts',
          type: 'nav',
          onPress: () => router.push('/addressbook' as any),
        },
      ],
    },
    {
      title: 'About',
      items: [
        { icon: '', label: 'Version',        sublabel: '1.0.0', type: 'info' },
        { icon: '', label: 'Encryption',     sublabel: 'AES-256-GCM', type: 'info' },
        { icon: '',  label: 'Networks',       sublabel: `${CHAINS.length} chains supported`, type: 'info' },
      ],
    },
    {
      title: 'Danger Zone',
      items: [
        {
          icon: '🗑', label: 'Wipe Wallet',
          sublabel: 'Remove all data from device',
          type: 'action', color: '#EF4444',
          onPress: confirmWipe,
        },
      ],
    },
  ]

  return (
    <View style={s.c}>
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity style={s.back} onPress={() => router.back()} activeOpacity={0.7}>
          <Text style={{ fontSize: 20, color: '#1E1B4B' }}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Settings</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 48 }}>

        {/* Profile card */}
        <View style={[s.profileCard, { backgroundColor: activeChain.color }]}>
          <View style={s.avatar}><Text style={s.avatarT}>V</Text></View>
          <View>
            <Text style={s.profileLabel}>VaultON Wallet</Text>
            <Text style={s.profileAddr}>{short}</Text>
          </View>
          <TouchableOpacity style={s.copyBtn} onPress={copyAddress} activeOpacity={0.8}>
            <Text style={s.copyBtnT}>{copied ? ' Copied' : 'Copy'}</Text>
          </TouchableOpacity>
        </View>

        {sections.map(sec => (
          <View key={sec.title} style={s.section}>
            <Text style={s.sectionTitle}>{sec.title}</Text>
            <View style={s.card}>
              {sec.items.map((item, idx) => (
                <TouchableOpacity
                  key={item.label}
                  style={[s.row, idx < sec.items.length - 1 && s.rowBorder]}
                  onPress={item.type !== 'toggle' && item.type !== 'info' ? item.onPress : undefined}
                  activeOpacity={item.type === 'info' || item.type === 'toggle' ? 1 : 0.7}
                >
                  <View style={[s.iconWrap, { backgroundColor: item.color ? '#FEF2F2' : activeChain.bgColor }]}>
                    <Text style={s.iconT}>{item.icon}</Text>
                  </View>
                  <View style={s.rowMid}>
                    <Text style={[s.rowLabel, item.color ? { color: item.color } : {}]}>{item.label}</Text>
                    {item.sublabel && <Text style={s.rowSub}>{item.sublabel}</Text>}
                  </View>
                  {item.type === 'toggle' && (
                    <Switch
                      value={item.value}
                      onValueChange={item.onToggle}
                      trackColor={{ false: '#E2E8F0', true: activeChain.color + '80' }}
                      thumbColor={item.value ? activeChain.color : '#fff'}
                    />
                  )}
                  {item.type === 'nav' && (
                    <Text style={{ fontSize: 20, color: '#1E1B4B' }}>←</Text>
                  )}
                  {item.type === 'info' && (
                    <Text style={s.infoVal}>{item.sublabel}</Text>
                  )}
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

      </ScrollView>
    </View>
  )
}

const s = StyleSheet.create({
  c:            { flex: 1, backgroundColor: '#F8FAFF' },
  header:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingTop: 60, paddingBottom: 16 },
  back:         { width: 38, height: 38, borderRadius: 12, backgroundColor: '#fff', borderWidth: 1, borderColor: '#E2E8F0', alignItems: 'center', justifyContent: 'center' },
  backT:        { fontSize: 18, color: '#1E1B4B' },
  title:        { color: '#1E1B4B', fontSize: 18, fontWeight: '700' },
  profileCard:  { marginHorizontal: 16, marginBottom: 24, borderRadius: 20, padding: 18, flexDirection: 'row', alignItems: 'center', gap: 14, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 12, elevation: 5 },
  avatar:       { width: 46, height: 46, borderRadius: 23, backgroundColor: 'rgba(255,255,255,0.25)', alignItems: 'center', justifyContent: 'center' },
  avatarT:      { color: '#fff', fontSize: 20, fontWeight: '700' },
  profileLabel: { color: '#fff', fontSize: 15, fontWeight: '700' },
  profileAddr:  { color: 'rgba(255,255,255,0.7)', fontSize: 12, marginTop: 2 },
  copyBtn:      { marginLeft: 'auto' as any, backgroundColor: 'rgba(255,255,255,0.2)', paddingVertical: 7, paddingHorizontal: 14, borderRadius: 20 },
  copyBtnT:     { color: '#fff', fontSize: 13, fontWeight: '600' },
  section:      { paddingHorizontal: 16, marginBottom: 20 },
  sectionTitle: { color: '#94A3B8', fontSize: 12, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 8, paddingLeft: 4 },
  card:         { backgroundColor: '#fff', borderRadius: 18, borderWidth: 1, borderColor: '#F1F5F9', overflow: 'hidden' },
  row:          { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16, gap: 12 },
  rowBorder:    { borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  iconWrap:     { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  iconT:        { fontSize: 17 },
  rowMid:       { flex: 1 },
  rowLabel:     { color: '#1E1B4B', fontSize: 15, fontWeight: '500' },
  rowSub:       { color: '#94A3B8', fontSize: 12, marginTop: 2 },
  chevron:      { color: '#CBD5E1', fontSize: 20, fontWeight: '300' },
  infoVal:      { color: '#94A3B8', fontSize: 13 },
})
