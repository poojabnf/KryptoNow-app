import { useEffect } from 'react'
import { Stack } from 'expo-router'
import { StatusBar } from 'expo-status-bar'
import { View, StyleSheet } from 'react-native'
import { LockProvider, useLockContext } from '../context/LockContext'
import LockScreen from '../components/LockScreen'
import AIAssistant from '../components/AIAssistant'

function AppShell() {
  const { lockState } = useLockContext()

  if (lockState === 'loading') return null

  if (lockState === 'no_pin') {
    return (
      <>
        <StatusBar style="light" />
        <LockScreen isSetup />
      </>
    )
  }

  if (lockState === 'locked') {
    return (
      <>
        <StatusBar style="light" />
        <LockScreen />
      </>
    )
  }

  return (
    <>
      <StatusBar style="auto" />
      <Stack screenOptions={{ headerShown: false }} />
      <View style={s.floatLayer} pointerEvents="box-none">
        <AIAssistant />
      </View>
    </>
  )
}

export default function Layout() {
  return (
    <LockProvider>
      <AppShell />
    </LockProvider>
  )
}

const s = StyleSheet.create({
  floatLayer: {
    position: 'absolute', top:0, left:0, right:0, bottom:0,
    zIndex: 999, pointerEvents: 'box-none',
  },
})
