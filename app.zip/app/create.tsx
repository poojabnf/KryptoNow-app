import { useState, useEffect } from 'react'
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, Alert, ActivityIndicator,
} from 'react-native'
import { router } from 'expo-router'
import { useWalletStore } from '../store/walletStore'
import { generateMnemonic, deriveWallet } from '../utils/crypto'
import { saveWalletKeys } from '../store/keyStore'

export default function CreateWallet() {
  const [mnemonic,  setMnemonic]  = useState<string[]>([])
  const [revealed,  setRevealed]  = useState(false)
  const [saving,    setSaving]    = useState(false)
  const [generated, setGenerated] = useState(false)

  const setWallet = useWalletStore(s => s.setWallet)

  // Generate real BIP-39 mnemonic on mount — replaces hardcoded fake words
  useEffect(() => {
    const phrase = generateMnemonic()
    setMnemonic(phrase.split(' '))
    setGenerated(true)
  }, [])

  function reveal() {
    Alert.alert(
      'Keep Private',
      'Make sure no one can see your screen. These words are the only way to recover your wallet.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Show Words', onPress: () => setRevealed(true) },
      ]
    )
  }

  async function finish() {
    if (mnemonic.length === 0) return
    setSaving(true)
    try {
      const phrase  = mnemonic.join(' ')
      const wallet  = deriveWallet(phrase)

      // Store private key + mnemonic in Secure Enclave (biometric if available)
      await saveWalletKeys(wallet.privateKey, phrase)

      // Only store the address in Zustand (public, non-sensitive)
      setWallet(wallet.address)

      router.replace('/dashboard')
    } catch (e: any) {
      Alert.alert(
        'Setup Failed',
        e?.message ?? 'Could not save wallet. Please try again.',
        [{ text: 'OK' }]
      )
    } finally {
      setSaving(false)
    }
  }

  return (
    <View style={s.c}>
      <View style={s.hdr}>
        <TouchableOpacity style={s.back} onPress={() => router.back()}>
          <Text style={s.backT}>←</Text>
        </TouchableOpacity>
        <View style={s.pill}><Text style={s.pillT}>Step 1 of 1</Text></View>
      </View>

      <ScrollView style={s.scroll} showsVerticalScrollIndicator={false}>
        <Text style={s.title}>Your Secret{'\n'}Recovery Phrase</Text>
        <Text style={s.sub}>
          Write these 12 words on paper and store them safely. This is the only way to recover your wallet — VaultON never stores them on our servers.
        </Text>
        <View style={s.warn}>
          <Text style={s.warnT}>⚠  Never share these words with anyone, ever.</Text>
        </View>

        <View style={s.card}>
          {!generated ? (
            <View style={s.blur}>
              <ActivityIndicator color="#6366F1" />
              <Text style={s.rs}>Generating secure phrase…</Text>
            </View>
          ) : revealed ? (
            <View style={s.grid}>
              {mnemonic.map((w, i) => (
                <View key={i} style={s.wb}>
                  <Text style={s.wn}>{i + 1}</Text>
                  <Text style={s.wt}>{w}</Text>
                </View>
              ))}
            </View>
          ) : (
            <TouchableOpacity style={s.blur} onPress={reveal} activeOpacity={0.8}>
              <Text style={{ fontSize: 28 }}>🔒</Text>
              <Text style={s.rt}>Tap to reveal</Text>
              <Text style={s.rs}>Make sure no one is watching</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Security badge — shows after reveal */}
        {revealed && (
          <>
            <View style={s.secCard}>
              <Text style={s.secTitle}>🔐 How your keys are protected</Text>
              <Text style={s.secDesc}>
                Your private key is derived from these words and stored in your device's{' '}
                <Text style={s.secBold}>Secure Enclave</Text> (iOS Keychain / Android Keystore).
                It never leaves your device and is protected by Face ID or fingerprint.
              </Text>
            </View>

            <View style={s.tips}>
              {[
                'Write on paper — not on your phone',
                'Store in a safe, secure location',
                'Never take a screenshot of these words',
                'VaultON cannot recover this for you',
              ].map(t => (
                <View key={t} style={s.tip}>
                  <Text style={s.tc}>✓</Text>
                  <Text style={s.tt}>{t}</Text>
                </View>
              ))}
            </View>
          </>
        )}

        <View style={{ height: 120 }} />
      </ScrollView>

      <View style={s.bot}>
        {!revealed ? (
          <TouchableOpacity style={s.bo} onPress={reveal} disabled={!generated}>
            <Text style={s.bot2}>Reveal Seed Phrase</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={[s.bp, saving && { opacity: 0.7 }]}
            onPress={finish}
            disabled={saving}
          >
            {saving
              ? <ActivityIndicator color="#fff" />
              : <Text style={s.bpt}>I've Written It Down →</Text>
            }
          </TouchableOpacity>
        )}
      </View>
    </View>
  )
}

const s = StyleSheet.create({
  c:        { flex:1, backgroundColor:'#F8FAFF' },
  hdr:      { flexDirection:'row', alignItems:'center', justifyContent:'space-between', paddingHorizontal:20, paddingTop:60, paddingBottom:16 },
  back:     { width:38, height:38, borderRadius:12, backgroundColor:'#fff', borderWidth:1, borderColor:'#E2E8F0', alignItems:'center', justifyContent:'center' },
  backT:    { color:'#6366F1', fontSize:18 },
  pill:     { backgroundColor:'#EEF2FF', paddingVertical:5, paddingHorizontal:12, borderRadius:20 },
  pillT:    { color:'#6366F1', fontSize:12, fontWeight:'500' },
  scroll:   { flex:1, paddingHorizontal:24 },
  title:    { fontSize:28, fontWeight:'700', color:'#1E1B4B', letterSpacing:-0.5, marginBottom:10, lineHeight:36 },
  sub:      { fontSize:14, color:'#64748B', lineHeight:22, marginBottom:18 },
  warn:     { backgroundColor:'#FFFBEB', borderWidth:1, borderColor:'#FDE68A', borderRadius:12, padding:13, marginBottom:20 },
  warnT:    { color:'#92400E', fontSize:13, lineHeight:18 },
  card:     { backgroundColor:'#fff', borderRadius:18, borderWidth:1, borderColor:'#E2E8F0', overflow:'hidden', marginBottom:20 },
  grid:     { padding:14, flexDirection:'row', flexWrap:'wrap', gap:7 },
  wb:       { width:'30%', backgroundColor:'#F8FAFC', borderRadius:9, paddingVertical:9, paddingHorizontal:8, flexDirection:'row', alignItems:'center', gap:5, borderWidth:1, borderColor:'#E2E8F0' },
  wn:       { color:'#CBD5E1', fontSize:10, fontWeight:'600', minWidth:14 },
  wt:       { color:'#1E1B4B', fontSize:13, fontWeight:'600' },
  blur:     { height:180, alignItems:'center', justifyContent:'center', backgroundColor:'#F8FAFC', gap:6 },
  rt:       { color:'#6366F1', fontSize:15, fontWeight:'600' },
  rs:       { color:'#94A3B8', fontSize:12 },
  secCard:  { backgroundColor:'#EEF2FF', borderRadius:14, borderWidth:1, borderColor:'#C7D2FE', padding:16, marginBottom:16 },
  secTitle: { color:'#4338CA', fontSize:13, fontWeight:'700', marginBottom:6 },
  secDesc:  { color:'#4338CA', fontSize:13, lineHeight:20 },
  secBold:  { fontWeight:'700' },
  tips:     { gap:10, marginBottom:8 },
  tip:      { flexDirection:'row', gap:10, alignItems:'flex-start' },
  tc:       { color:'#10B981', fontSize:14 },
  tt:       { flex:1, color:'#64748B', fontSize:13, lineHeight:18 },
  bot:      { padding:24, paddingBottom:40, backgroundColor:'#fff', borderTopWidth:1, borderTopColor:'#F1F5F9' },
  bo:       { paddingVertical:17, borderRadius:16, alignItems:'center', borderWidth:1.5, borderColor:'#6366F1' },
  bot2:     { color:'#6366F1', fontSize:16, fontWeight:'600' },
  bp:       { backgroundColor:'#6366F1', paddingVertical:18, borderRadius:16, alignItems:'center', shadowColor:'#6366F1', shadowOffset:{width:0,height:4}, shadowOpacity:0.3, shadowRadius:12, elevation:6 },
  bpt:      { color:'#fff', fontSize:16, fontWeight:'600' },
})
