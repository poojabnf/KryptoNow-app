import { View, Text, TouchableOpacity, StyleSheet } from 'react-native'
import { router } from 'expo-router'
export default function Welcome() {
  return (
    <View style={s.c}>
      <View style={s.logo}>
        <View style={s.ring}><View style={s.core} /></View>
        <Text style={s.name}>VaultON</Text>
        <Text style={s.tag}>Your vault. Your rules.</Text>
      </View>
      <TouchableOpacity style={s.bp} onPress={()=>router.push('/create')}>
        <Text style={s.bpt}>Create New Wallet</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.bs} onPress={()=>router.push('/import')}>
        <Text style={s.bst}>Import Existing Wallet</Text>
      </TouchableOpacity>
    </View>
  )
}
const s = StyleSheet.create({
  c:{flex:1,backgroundColor:'#F8FAFF',paddingHorizontal:24,paddingTop:80,paddingBottom:48,justifyContent:'space-between'},
  logo:{flex:1,alignItems:'center',justifyContent:'center'},
  ring:{width:88,height:88,borderRadius:28,backgroundColor:'#fff',borderWidth:1.5,borderColor:'#E0E7FF',alignItems:'center',justifyContent:'center',marginBottom:20},
  core:{width:52,height:52,borderRadius:16,backgroundColor:'#6366F1'},
  name:{fontSize:36,fontWeight:'700',color:'#1E1B4B'},
  tag:{fontSize:15,color:'#818CF8',marginTop:6},
  bp:{backgroundColor:'#6366F1',paddingVertical:18,borderRadius:16,alignItems:'center',marginBottom:12},
  bpt:{color:'#fff',fontSize:16,fontWeight:'600'},
  bs:{backgroundColor:'#fff',paddingVertical:17,borderRadius:16,alignItems:'center',borderWidth:1.5,borderColor:'#E0E7FF'},
  bst:{color:'#6366F1',fontSize:16,fontWeight:'500'},
})
